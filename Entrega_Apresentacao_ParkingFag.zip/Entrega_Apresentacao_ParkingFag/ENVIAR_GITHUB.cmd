@echo off
setlocal EnableExtensions
set "PARKING_REPO=%~1"
if not defined PARKING_REPO set "PARKING_REPO=%USERPROFILE%\Desktop\GPT\Nova pasta\Testes-Seguran-a-TCC-ParkingFag"
set "PARKING_BUNDLE=%~dp0entrega.bundle"
set "PARKING_BRANCH=codex/cicd-apresentacao"
if not exist "%PARKING_REPO%\.git" (
  echo Repositorio nao encontrado: "%PARKING_REPO%"
  echo Execute ENVIAR_GITHUB.cmd "CAMINHO_DO_REPOSITORIO"
  pause
  exit /b 1
)
for /f "delims=" %%u in ('git -C "%PARKING_REPO%" remote get-url origin') do set "PARKING_ORIGIN=%%u"
if /I not "%PARKING_ORIGIN%"=="https://github.com/Dazorafi/Testes-Seguran-a-TCC-ParkingFag.git" (
  echo O origin nao corresponde ao repositorio da entrega. Nenhum envio foi feito.
  echo Origin encontrado: "%PARKING_ORIGIN%"
  pause
  exit /b 1
)
git -C "%PARKING_REPO%" bundle verify "%PARKING_BUNDLE%"
if errorlevel 1 (
  git -C "%PARKING_REPO%" fetch origin main
  if errorlevel 1 goto failed
  git -C "%PARKING_REPO%" bundle verify "%PARKING_BUNDLE%"
  if errorlevel 1 goto failed
)
git -C "%PARKING_REPO%" fetch "%PARKING_BUNDLE%" "refs/heads/%PARKING_BRANCH%:refs/heads/%PARKING_BRANCH%"
if errorlevel 1 goto failed
git -C "%PARKING_REPO%" push -u origin "%PARKING_BRANCH%"
if errorlevel 1 goto failed
echo.
echo Envio concluido. Abra o Pull Request para main:
echo https://github.com/Dazorafi/Testes-Seguran-a-TCC-ParkingFag/compare/main...codex/cicd-apresentacao?expand=1
echo Depois siga APRESENTACAO.md para preparar o computador de destino.
pause
exit /b 0

:failed
echo.
echo O envio nao foi concluido. O commit permanece preservado no bundle.
echo Nao use force ou reset. Envie a mensagem de erro para conferir.
pause
exit /b 1
