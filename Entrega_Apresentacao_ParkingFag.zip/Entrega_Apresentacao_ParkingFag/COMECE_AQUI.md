# Entrega consolidada para a apresentacao

Preparada em 29/10/2026 para a apresentacao de 30/10/2026.

## O que ja esta pronto

- Commit local `3e99f89ce933e33d682e948203735fa5f38f0f66` na branch `codex/cicd-apresentacao`.
- Workflows de testes em PR e deploy local apos CI aprovado.
- Correcao das duas falhas encontradas, mantendo os testes ativos.
- Roteiro para preparar o computador Windows hoje e demonstrar pelo notebook.
- Guia com as falas e exemplos reais dos testes.
- Evidencias historicas e da versao corrigida no repositorio.
- Pagina `/versao.html`, gerada no deploy, para comparar o commit em execucao com o GitHub.

O envio direto desta sessao falhou porque ela nao consegue acessar o armazenamento de credenciais do Git no Windows. O commit foi preservado e esta no arquivo `entrega.bundle`. O pacote nao confirma um push, uma execucao no GitHub Actions ou um deploy real.

## 1. Enviar pelo seu computador atual

Extraia todo o ZIP, mantendo `ENVIAR_GITHUB.cmd` ao lado de `entrega.bundle`. Execute **`ENVIAR_GITHUB.cmd`**. Ele utiliza o repositorio existente em:

```text
C:\Users\Ti\Desktop\GPT\Nova pasta\Testes-Seguran-a-TCC-ParkingFag
```

O script verifica o destino, importa a branch com o commit ja criado e faz o push usando a autenticacao normal do seu Windows. Pode ser necessario concluir a autenticacao no navegador. Ele nao troca a branch de trabalho, nao apaga arquivos, nao usa force e nao faz merge em main.

Se o repositorio estiver em outra pasta, execute no Prompt aberto na pasta extraida:

```cmd
ENVIAR_GITHUB.cmd "CAMINHO_DO_REPOSITORIO"
```

Se aparecer erro, pare e envie a mensagem. Nao precisa copiar as pastas dos tres projetos novamente nem aplicar o patch da entrega anterior: este commit ja contem a atualizacao inteira.

## 2. Abrir o Pull Request

Depois que o push terminar, abra:

[Comparar e abrir o PR](https://github.com/Dazorafi/Testes-Seguran-a-TCC-ParkingFag/compare/main...codex/cicd-apresentacao?expand=1)

Crie o PR para `main` e acompanhe **Checks**. O nome sugerido e `CI/CD e guia de apresentacao do Parking FAG`.

Somente depois de aprovar os checks e preparar o computador de destino, faca o merge. O merge dispara o CI de main e, depois de sua aprovacao, o deploy.

## 3. Preparar o computador que ficara ligado

Leia **`APRESENTACAO.md`** deste pacote. Ele contem a sequencia completa para:

1. Instalar/preparar Git, MySQL e cloudflared.
2. Clonar a branch correta.
3. Criar `shared/backend.env` com o banco local, sem enviar senha ao Git.
4. Cadastrar o runner no GitHub com rotulo `parking-fag`.
5. Deixar `run.cmd` ativo, realizar o primeiro deploy e abrir o tunel.
6. Testar pelo celular fora do Wi-Fi e guardar o HTTPS para o notebook.

O runner e a configuracao do banco ainda precisam ser feitos nesse computador. A automacao nao compra hospedagem nem faz o sistema funcionar com a maquina desligada.

## Arquivos

| Arquivo | Uso |
|---|---|
| `ENVIAR_GITHUB.cmd` | Importar e enviar a branch pelo seu Windows |
| `entrega.bundle` | Commit pronto para importar no repositorio existente |
| `codigo-completo.zip` | Backup dos fontes e documentos do commit, sem dependencias instaladas ou historicos internos |
| `APRESENTACAO.md` | Preparacao e roteiro de demonstracao |
| `GUIA_TESTES_PARA_FALAR.md` | Explicacao de IDOR, tokens, injecao e bots |
| `GUIA_CICD.md` | Detalhes de CI, runner e deploy |

No outro computador, prefira clonar do GitHub depois do envio, para o runner e a demonstracao utilizarem a mesma revisao. `codigo-completo.zip` e um backup sem pasta `.git`, e nao e necessario para executar o script de envio.
